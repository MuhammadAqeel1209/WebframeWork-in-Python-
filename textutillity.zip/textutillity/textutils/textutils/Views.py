from django.http import HttpResponse
from django.shortcuts import render
# from django.core.mail import send_mail, BadHeaderError

# def index(request):
#     return  HttpResponse('''<h1>Hello Aqeel</h1>
#      <a href="https://www.youtube.com/watch?v=AepgWsROO4k&list=PLu0W_9lII9ah7DDtYtflgwMwpT3xmjXY9&index=7"> Django Code With Harry <a/>''')
#
# def about(request):
#     return  HttpResponse("About Aqeel")


# --> Home Page 
def index(request):
    # params = {'name':'Aqeel','place':'Pakistan'}
    return  render(request,'index.html')
    #return  HttpResponse("Home")

# --> Analyze Page 
def Analyze(request):
   #Get the text
    djtext = request.POST.get('text', 'default') 
    removepunc = request.POST.get('removepunc','off')   
    fullcaps = request.POST.get('fullcaps','off')   
    newline = request.POST.get('newline','off') 
    charcount = request.POST.get('charcount','off') 

# --> Remove Punctuations
    if removepunc == "on":
        punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
        analyzed = ""
        for char in djtext:
            if char not in punctuations:
                analyzed = analyzed + char
        params = {'purpose': 'Removed Punctuations', 'analyzed_text': analyzed}
        djtext = analyzed
        # return render(request,'analyze.html',params)

    # --> Count the Char     
    if(charcount == 'on'):
        analyzed = ""
        count  = 0
        for char in djtext:
            count += 1
            params = {'purpose': 'Char Count ', 'analyzed_text': count}
            djtext = analyzed
    
# --> Remove the New Line
    if(newline == 'on'):
        analyzed = ""
        for char in djtext:
            if char != "\n" and char != "\r":
                analyzed = analyzed + char
            params = {'purpose': 'New Line Remove', 'analyzed_text': analyzed}
            djtext = analyzed
        # return render(request,'analyze.html',params)

    # --> Convert into UpperCase
    if(fullcaps == "on"):
        analyzed = ""
        for char in djtext:
            analyzed = analyzed + char.upper() + " "
            params = {'purpose': 'Convert into UpperCase', 'analyzed_text': analyzed}
            djtext = analyzed
        # return render(request,'analyze.html',params)

        if(removepunc != "on" and newline !="on" and charcount !="on" and fullcaps !="on"):
            return HttpResponse("please select any operation and try again")        
        # return render(request,'analyze.html',params)
    return render(request,'analyze.html',params)  


def Contact(request):
    return render(request,'contact.html')  

def About(request):
    return render(request,'about.html')

# def your_form_view(request):
#     if(request.method == 'GET'):
#         try:
#             subject = 'Form Submission Notification'
#             sender_email = request.form.get('email')
#             recipient_email = 'aqeelshakeel892@gmail.com'
#             message = request.form.get('message')

#             send_mail(subject, message, sender_email, [recipient_email])

#         # Redirect or render success page after sending the notification
#             return HttpResponseRedirect('/success/')
#         except BadHeaderError:
#             # Handle BadHeaderError
#             return HttpResponse('Invalid header found.')
#         except Exception as e:
#             # Handle other exceptions
#             print(str(e))  # Print the exception for debugging purposes
#             return HttpResponse('An error occurred while sending the notification.')
#     else:
#         # Render your form
#         return HttpResponse('An error occurred while sending the notification.')


# def Removepunc(request):
#     djText = request.GET.get('text','default')
#     print(djText)
#     return  HttpResponse("Remove the punc")

# def CapFirst(request):
#     return  HttpResponse("Capitilize First")

# def newlineremove(request):
#     return HttpResponse("New Line")
# def spaceremove(request):
#     return HttpResponse("space remover <a href ='/'>back</a>")

# def charcount(request):
#     return HttpResponse("charcount ")